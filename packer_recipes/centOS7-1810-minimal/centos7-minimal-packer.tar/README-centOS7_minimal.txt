to run the centos7-minimal-.json run the command: "packer build centos7-minimal-.json"
in the same directory as the json file. 

--> NOTE: if you want to use a local iso, make sure the iso path varriable and iso name varriable
reflect the local iso you are trying to use. Otherwise, the url will grab the iso from the web. 
