#!/bin/bash -eux

# this will update the system and then install various software

yum update -y

yum install vim -y

