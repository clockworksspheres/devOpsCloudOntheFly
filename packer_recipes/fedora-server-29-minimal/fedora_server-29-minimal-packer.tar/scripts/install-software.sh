#!/bin/bash -eux

# this will update the system and then install various software

yum -y update

yum install -y vim


